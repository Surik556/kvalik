//
//  ContentView.swift
//  kvalik
//
//  Created by Сурен Мейроян on 23.12.2025.
//

import SwiftUI

struct ContentView: View {
    // Ежедневная цель (мл), сохраняется между запусками
    @AppStorage("dailyGoalML") private var dailyGoalML: Int = 2000

    // Текущее потребление воды (мл) и дата последнего обновления
    @AppStorage("todayIntakeML") private var todayIntakeML: Int = 0
    @AppStorage("todayDate") private var todayDateString: String = Self.dateString(for: Date())

    // Шаг добавления воды
    private let stepML = 250

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                // Заголовок и дата
                VStack(spacing: 8) {
                    Text("Трекер воды 💧")
                        .font(.largeTitle).bold()
                    Text(Self.localizedDateString(for: Date()))
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                // Прогресс
                VStack(spacing: 12) {
                    let progress = min(Double(todayIntakeML) / Double(max(dailyGoalML, 1)), 1.0)
                    ProgressView(value: progress)
                        .tint(.blue)
                        .scaleEffect(x: 1, y: 2, anchor: .center)
                        .padding(.horizontal)

                    Text("\(todayIntakeML) мл из \(dailyGoalML) мл")
                        .font(.headline)
                        .monospacedDigit()
                        .accessibilityLabel("Выпито \(todayIntakeML) миллилитров из \(dailyGoalML)")
                }

                // Кнопка добавления воды
                Button {
                    addWater(stepML)
                } label: {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                            .imageScale(.large)
                        Text("+\(stepML) мл")
                            .font(.title3).bold()
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.blue)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .padding(.horizontal)

                // Быстрые шаги (на выбор)
                HStack(spacing: 12) {
                    ForEach([150, 250, 500], id: \.self) { amount in
                        Button {
                            addWater(amount)
                        } label: {
                            Text("+\(amount) мл")
                                .font(.subheadline).bold()
                                .padding(.vertical, 10)
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.horizontal)

                // Настройка цели
                VStack(alignment: .leading, spacing: 8) {
                    Text("Цель на день")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                    HStack(spacing: 12) {
                        Stepper(value: $dailyGoalML, in: 500...10000, step: 100) {
                            Text("\(dailyGoalML) мл")
                                .font(.headline)
                                .monospacedDigit()
                        }

                        Button("Сбросить") {
                            resetToday()
                        }
                        .buttonStyle(.bordered)
                    }
                }
                .padding(.horizontal)

                Spacer()

                // Подсказка
                Text("Совет: цель — около 30–35 мл на 1 кг веса")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                    .padding(.bottom, 16)
            }
            .onAppear(perform: ensureToday)
            .navigationTitle("Вода")
        }
    }

    // MARK: - Логика

    private func addWater(_ amount: Int) {
        ensureToday()
        todayIntakeML = min(todayIntakeML + amount, 100_000) // защита от переполнения
    }

    private func resetToday() {
        todayIntakeML = 0
        todayDateString = Self.dateString(for: Date())
    }

    // Сбрасываем прогресс при смене календарного дня
    private func ensureToday() {
        let current = Self.dateString(for: Date())
        if todayDateString != current {
            todayDateString = current
            todayIntakeML = 0
        }
    }

    // Форматирование даты для хранения (YYYY-MM-DD)
    private static func dateString(for date: Date) -> String {
        let cal = Calendar.current
        let comps = cal.dateComponents([.year, .month, .day], from: date)
        let y = comps.year ?? 0
        let m = comps.month ?? 0
        let d = comps.day ?? 0
        return String(format: "%04d-%02d-%02d", y, m, d)
    }

    // Локализованный вывод даты (например: 23 дек. 2025)
    private static func localizedDateString(for date: Date) -> String {
        date.formatted(.dateTime.day().month(.abbreviated).year())
    }
}

#Preview {
    ContentView()
}
